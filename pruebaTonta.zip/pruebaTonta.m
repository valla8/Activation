% C?digo de prueba de c?lculo de actividad con Zn
% (C) Daniel S?nchez Parcerisa 2018
% dsparcerisa@ucm.es

%% Par?metros a modificar:
clear all
Zn_fraction = 0.1; % Fraccion de Zn (tanto por uno)
dx = 0.1; % Espaciado de la malla (cm)
E0 = 150; % Energ?a inicial del haz (MeV)

%% Cargar datos
% Secciones de EXFOR.
load('CrossSections.mat');
% Vidas medias en s
load('MeanLives.mat');
landa_C10 = log(2) / T_C10;
landa_C11 = log(2) / T_C11;
landa_Ga64 = log(2) / T_Ga64;
landa_Ga66 = log(2) / T_Ga66;
landa_Ga68 = log(2) / T_Ga68;
landa_N13 = log(2) / T_N13;
landa_O15 = log(2) / T_O15;

% Natural abundances
O16_ab = 0.998; %1
N14_ab = 0.996; %2
C12_ab = 0.989; %3
Zn64_ab = 0.492; %4
Zn66_ab = 0.277; %5
Zn68_ab = 0.185; %6
ab = [O16_ab N14_ab C12_ab Zn64_ab Zn66_ab Zn68_ab];

% Tissue compositions (fuente: Zhu 2011, ICRU Report #63, ICRU Report #44)
% Material H (%) C (%) N (%) O (%) Zn64(%) Zn66(%) Zn68(%)  Density (g ml?1)
% Soft tissue 0.102 0.143 0.034 0.708 0 0 0 1.06
% Water: 0.0305 0 0 0.9695 0 0 0 1.00
Comp_tissue = [0.102 0.143 0.034 0.708 0 0 0];
Comp_water = [0.0305 0 0 0.9695 0 0 0];
Comp_Zn = [0 0 0 0 Zn64_ab Zn66_ab Zn68_ab];
Comp_tissue_Zn = Zn_fraction*Comp_Zn + (1-Zn_fraction)*Comp_tissue;
Comp_water_Zn = Zn_fraction*Comp_Zn + (1-Zn_fraction)*Comp_water;

% Cargar stopping powers (only for water, tissue, Zn)
load('stoppingpowers.mat');

%% Fit secciones eficaces ZN-Ga
figure
Eval = 0:0.1:300; % MeV
hold off
plot(Zn66_Ga66_E,Zn66_Ga66_CS,'bo')
hold on
Zn66_Ga66_F = fit(Zn66_Ga66_E,Zn66_Ga66_CS,'smoothingspline','SmoothingParam',0.1);
Zn66_Ga66_F.p.coefs(1,:) = [0 0 0 0];
Zn66_Ga66_F.p.coefs(end,:) = [0 0 0 0];

axis([0 100 0 0.8]);

% Las secciones eficaces de Zn64 y Zn68 se calculan modificando
% manualmente el fit para la secci?n eficaz del Zn66 ajustando
% a los puntos experimentales existentes.

plot(Eval,Zn66_Ga66_F(Eval),'b-');
plot(Zn64_Ga64_E,Zn64_Ga64_CS,'xg')
Zn64_Ga64_F = @(x) Zn66_Ga66_F(x-3);
plot(Eval,Zn64_Ga64_F(Eval),'g-')
Zn68_Ga68_F = @(x) 1.3 * Zn66_Ga66_F(x+1.5);
plot(Zn68_Ga68_E,Zn68_Ga68_CS,'kd')
plot(Eval,Zn68_Ga68_F(Eval),'k-')
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
legend('Zn66 data','Zn66 fit','Zn64 data','Zn64 fit','Zn68 data','Zn68 fit')
title('Zn cross sections')

%% Fit secciones eficaces C12_C10
figure
plot(C12_C10_E,C12_C10_CS,'bo'); hold on
C12_C10_F = fit(C12_C10_E,C12_C10_CS,'smoothingspline','SmoothingParam',0.999)
C12_C10_F.p.coefs(1,:) = [0 0 0 0]
plot(Eval,C12_C10_F(Eval),'r-')
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('C12->C10 cross sections')
%axis([0 100 0 0.2]);

%% Fit secciones eficaces  C12_C11
figure
hold off
plot(C12_C11_E,C12_C11_CS,'bo'); hold on
C12_C11_F = fit(C12_C11_E,C12_C11_CS,'smoothingspline','SmoothingParam',0.1)
C12_C11_F.p.coefs(1,:) = [0 0 0 0]
plot(Eval,C12_C11_F(Eval),'r-')
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('C12->C11 cross sections')

%% Fit secciones eficaces  N14_C11
figure
hold off
plot(N14_C11_E,N14_C11_CS,'bo'); hold on
N14_C11_F = fit(N14_C11_E,N14_C11_CS,'smoothingspline','SmoothingParam',0.999)
N14_C11_F.p.coefs(1,:) = [0 0 0 0]
plot(Eval,N14_C11_F(Eval),'r-')
axis([0 200 0 0.4]);
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('N14->C11 cross sections')

%% Fit secciones eficaces  N14_N13
figure
hold off
plot(N14_N13_E,N14_N13_CS,'bo'); hold on
N14_N13_F = fit(N14_N13_E,N14_N13_CS,'smoothingspline','SmoothingParam',0.1)
N14_N13_F.p.coefs(1,:) = [0 0 0 0]
plot(Eval,N14_N13_F(Eval),'r-')
axis([0 200 0 0.1]);
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('N14->N13 cross sections')


%% Fit secciones eficaces O16_C11
figure
hold off
O16_C11_E(27) = 200;
O16_C11_CS(27) = O16_C11_CS(26);
plot(O16_C11_E,O16_C11_CS,'bo'); hold on
O16_C11_F = fit(O16_C11_E,O16_C11_CS,'smoothingspline','SmoothingParam',0.999)
O16_C11_F.p.coefs(1,:) = [0 0 0 0];
O16_C11_F.p.coefs(end,:) = [0 0 0 0];
plot(Eval,O16_C11_F(Eval),'r-')
axis([0 200 0 0.1]);
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('O16->C11 cross sections')

%% Fit secciones eficaces O16_N13
figure
hold off
plot(O16_N13_E,O16_N13_CS,'bo'); hold on
O16_N13_F = fit(O16_N13_E,O16_N13_CS,'smoothingspline','SmoothingParam',0.999)
O16_N13_F.p.coefs(1,:) = [0 0 0 0];
O16_N13_F.p.coefs(end,:) = [0 0 0 0];
plot(Eval,O16_N13_F(Eval),'r-')
axis([0 100 0 0.2]);
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('O16->N13 cross sections')

%% Fit secciones eficaces  O16_O15
figure
hold off
plot(O16_O15_E,O16_O15_CS,'bo'); hold on
O16_O15_F = fit(O16_O15_E,O16_O15_CS,'smoothingspline','SmoothingParam',0.002)
O16_O15_F.p.coefs(1,:) = [0 0 0 0];
O16_O15_F.p.coefs(end,:) = [0 0 0 0];
plot(Eval,O16_O15_F(Eval),'r-')
axis([0 300 0 0.2]);
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)')
title('O16->O15 cross sections')

%% Plot all (water)
figure
hold off
plot(Eval,O16_O15_F(Eval))
hold on
plot(Eval,O16_N13_F(Eval))
plot(Eval,O16_C11_F(Eval))
plot(Eval,Zn64_Ga64_F(Eval))  ; hold on
plot(Eval,Zn66_Ga66_F(Eval))
plot(Eval,Zn68_Ga68_F(Eval))
xlabel('Proton Energy (MeV)')
ylabel('Cross section (barn)');
legend('O16->O15','O16->N13','O16->C11','Zn64->Ga64','Zn66->Ga66','Zn68->Ga68');
title('All cross sections for water + Zn')
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
axis([1 300 1e-4 1]);

%% Plot all (tissue)
figure
hold off
plot(Eval,O16_O15_F(Eval))
hold on
plot(Eval,O16_N13_F(Eval))
plot(Eval,O16_C11_F(Eval))
plot(Eval,N14_N13_F(Eval))
plot(Eval,N14_C11_F(Eval))
plot(Eval,C12_C11_F(Eval))
plot(Eval,C12_C10_F(Eval))
plot(Eval,Zn64_Ga64_F(Eval))
plot(Eval,Zn66_Ga66_F(Eval))
plot(Eval,Zn68_Ga68_F(Eval))
xlabel('Proton energy (MeV)')
ylabel('Cross section (barn)');
legend('O16->O15','O16->N13','O16->C11','N14->N13','N14->C11','C12->C11','C12->C10','Zn64->Ga64','Zn66->Ga66','Zn68->Ga68');
title('All cross sections for tissue + Zn')
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
axis([1 300 1e-4 1]);

%% Create fit for stopping power
figure
S_Zn_F = fit(E_keV,S_Zn66,'smoothingspline','SmoothingParam',0.002)
S_Zn_F.p.coefs(1,:) = [0 0 0 0];
S_Zn_F.p.coefs(end,:) = [0 0 0 0];
S_w_F = fit(E_keV,S_w,'smoothingspline','SmoothingParam',0.002)
S_w_F.p.coefs(1,:) = [0 0 0 0];
S_w_F.p.coefs(end,:) = [0 0 0 0];
S_t_F = fit(E_keV,S_tissue,'smoothingspline','SmoothingParam',0.002)
S_t_F.p.coefs(1,:) = [0 0 0 0];
S_t_F.p.coefs(end,:) = [0 0 0 0];
loglog(E_keV,S_Zn_F(E_keV),'r-')
hold on;
loglog(E_keV,S_Zn66,'ro')
loglog(E_keV,S_w_F(E_keV),'b-')
loglog(E_keV,S_w,'bo')
loglog(E_keV,S_t_F(E_keV),'g-')
loglog(E_keV,S_tissue,'go')
legend('Zn66 fit','Zn66 SRIM data', 'Water fit', 'Water SRIM data', 'Tissue fit', 'Tissue SRIM data');
xlabel('Proton energy (MeV)');
ylabel('Stopping power (MeV/(cm2/mg))');

%% Calcular (sin straggling)

AvNmbr = 6.022140857e23;
waterMolecularWeight = 18.01528; %g/mol
rho_w = 1; % g/cm3
rho_Zn = 7.14; %g/cm3
rho_tissue = 1.06; %g/cm3
rho_tissue_A = 4.6243E+22; % atoms/cm3
rho_w_A = (1-Zn_fraction) * rho_w * AvNmbr / waterMolecularWeight; % molecules / cm3
ZnAtomicWeight = 65.38; % g/mol
rho_Zn_A = Zn_fraction * rho_Zn * AvNmbr / ZnAtomicWeight; % molecules / cm3
rho_O16_A = rho_w_A * O16_ab; % atoms/cm3
rho_O16_At = rho_tissue_A * Comp_tissue_Zn(4) * O16_ab;
rho_N14_At = rho_tissue_A * Comp_tissue_Zn(4) * N14_ab;
rho_C12_At = rho_tissue_A * Comp_tissue_Zn(4) * C12_ab;

x = 0:dx:30; % posiciones en cm.
E = nan(size(x));
Et = nan(size(x));

Ddep = zeros(size(E));
Ddept = zeros(size(E));

currentE = E0;
currentEt = E0;

% In water (full + simplified versions)
Y64 = nan(size(x));
Y66 = nan(size(x));
Y68 = nan(size(x));
Y64s = nan(size(x));
Y66s = nan(size(x));
Y68s = nan(size(x));
Y_O16_C11 = nan(size(x));
Y_O16_N13 = nan(size(x));
Y_O16_O15 = nan(size(x));
Y_O16_C11s = nan(size(x));
Y_O16_N13s = nan(size(x));
Y_O16_O15s = nan(size(x));

% In tissue (simplified form only)
Y64t = nan(size(x));
Y66t = nan(size(x));
Y68t = nan(size(x));
Y_O16_C11t = nan(size(x));
Y_O16_N13t = nan(size(x));
Y_O16_O15t = nan(size(x));
Y_N14_N13t = nan(size(x));
Y_N14_C11t = nan(size(x));   
Y_C12_C11t = nan(size(x));     
Y_C12_C10t = nan(size(x)); 

for i=1:(numel(x)-1)
    S_w = max(0,1000*S_w_F(currentE*1000)); % MeV/(g/cm2)
    S_Zn = max(0,1000*S_Zn_F(currentE*1000)); % MeV/(g/cm2) 
    S_Znt = max(0,1000*S_Zn_F(currentEt*1000)); % MeV/(g/cm2) 
    S_t = max(0,1000*S_t_F(currentEt*1000)); % MeV/(g/cm2)
    
    S1 = (S_w*rho_w*(1-Zn_fraction) + S_Zn*rho_Zn*Zn_fraction); % MeV/cm
    S1t = (S_t*rho_tissue*(1-Zn_fraction) + S_Znt*rho_Zn*Zn_fraction); % MeV/cm
    
    deltaE = dx*S1; % MeV
    deltaEt = dx*S1t; % MeV
    
    E(i) = currentE; % MeV
    Et(i) = currentEt; % MeV
    currentE = currentE - deltaE; % MeV
    currentEt = currentEt - deltaEt; % MeV
    
    S_w2 = max(0,1000*S_w_F(currentE*1000)); % MeV/(g/cm2)
    S_Zn2 = max(0,1000*S_Zn_F(currentE*1000)); % MeV/(g/cm2)
    S_t2 = max(0,1000*S_t_F(currentEt*1000)); % MeV/(g/cm2)
    S_Zn2t = max(0,1000*S_Zn_F(currentEt*1000)); % MeV/(g/cm2)   
    
    S2 = (S_w2*rho_w*(1-Zn_fraction) + S_Zn2*rho_Zn*Zn_fraction); % MeV/cm
    S2t = (S_t2*rho_tissue*(1-Zn_fraction) + S_Zn2t*rho_Zn*Zn_fraction); % MeV/cm
    
    Ddep(i) = deltaE; % MeV
    Ddept(i) = deltaEt; % MeV
    
    % Zn part
    E1 = E(i);
    E1t = Et(i);
    E2 = currentE;
    E2t = currentEt;
    E2E1 = [currentE E(i)];
    E2E1t = [currentEt Et(i)];
    
    % Water (full + simplified)
    Y64(i) = rho_Zn_A * Zn64_ab * trapz(E2E1, [Zn64_Ga64_F(E1)*1e-24/S1 Zn64_Ga64_F(E2)*1e-24/S2]);
    Y66(i) = rho_Zn_A * Zn66_ab * trapz(E2E1, [Zn66_Ga66_F(E1)*1e-24/S1 Zn66_Ga66_F(E2)*1e-24/S2]);
    Y68(i) = rho_Zn_A * Zn68_ab * trapz(E2E1, [Zn68_Ga68_F(E1)*1e-24/S1 Zn68_Ga68_F(E2)*1e-24/S2]);
    Y_O16_C11(i) = rho_O16_A * trapz(E2E1, [O16_C11_F(E1)*1e-24/S1 O16_C11_F(E2)*1e-24/S2]);
    Y_O16_N13(i) = rho_O16_A * trapz(E2E1, [O16_N13_F(E1)*1e-24/S1 O16_N13_F(E2)*1e-24/S2]);
    Y_O16_O15(i) = rho_O16_A * trapz(E2E1, [O16_O15_F(E1)*1e-24/S1 O16_O15_F(E2)*1e-24/S2]);
    sigma_64_mean = 0.5 * (Zn64_Ga64_F(E1) + Zn64_Ga64_F(E2));
    sigma_66_mean = 0.5 * (Zn66_Ga66_F(E1) + Zn66_Ga66_F(E2));
    sigma_68_mean = 0.5 * (Zn68_Ga68_F(E1) + Zn68_Ga68_F(E2));
    sigma_C11_mean = 0.5 * (O16_C11_F(E1) + O16_C11_F(E2));
    sigma_N13_mean = 0.5 * (O16_N13_F(E1) + O16_N13_F(E2));
    sigma_O15_mean = 0.5 * (O16_O15_F(E1) + O16_O15_F(E2));
    Y64s(i) = rho_Zn_A * Zn64_ab * sigma_64_mean * 1e-24 * dx;
    Y66s(i) = rho_Zn_A * Zn66_ab * sigma_66_mean * 1e-24 * dx;
    Y68s(i) = rho_Zn_A * Zn68_ab * sigma_68_mean * 1e-24 * dx;
    Y_O16_C11s(i) = rho_O16_A * sigma_C11_mean * 1e-24 * dx;
    Y_O16_N13s(i) = rho_O16_A * sigma_N13_mean * 1e-24 * dx;
    Y_O16_O15s(i) = rho_O16_A * sigma_O15_mean * 1e-24 * dx;
    
    % Tissue (simplified only)
    sigma_64_meant = 0.5 * (max(0,Zn64_Ga64_F(E1t)) + max(0,Zn64_Ga64_F(E2t)));
    sigma_66_meant = 0.5 * (max(0,Zn66_Ga66_F(E1t)) + max(0,Zn66_Ga66_F(E2t)));
    sigma_68_meant = 0.5 * (max(0,Zn68_Ga68_F(E1t)) + max(0,Zn68_Ga68_F(E2t)));
    sigma_C11_meant = 0.5 * (max(0,O16_C11_F(E1t)) + max(0,O16_C11_F(E2t)));
    sigma_N13_meant = 0.5 * (max(0,O16_N13_F(E1t)) + max(0,O16_N13_F(E2t)));
    sigma_O15_meant = 0.5 * (max(0,O16_O15_F(E1t)) + max(0,O16_O15_F(E2t)));
    sigma_N14_N13t = 0.5 * (max(0,N14_N13_F(E1t)) + max(0,N14_N13_F(E2t)));
    sigma_N14_C11t = 0.5 * (max(0,N14_C11_F(E1t)) + max(0,N14_C11_F(E2t)));
    sigma_C12_C11t = 0.5 * (max(0,C12_C11_F(E1t)) + max(0,C12_C11_F(E2t)));
    sigma_C12_C10t = 0.5 * (max(0,C12_C10_F(E1t)) + max(0,C12_C10_F(E2t)));
    Y64t(i) = rho_Zn_A * Zn64_ab * sigma_64_meant * 1e-24 * dx;
    Y66t(i) = rho_Zn_A * Zn66_ab * sigma_66_meant * 1e-24 * dx;
    Y68t(i) = rho_Zn_A * Zn68_ab * sigma_68_meant * 1e-24 * dx;
    Y_O16_C11t(i) = rho_O16_At * sigma_C11_meant * 1e-24 * dx;
    Y_O16_N13t(i) = rho_O16_At * sigma_N13_meant * 1e-24 * dx;
    Y_O16_O15t(i) = rho_O16_At * sigma_O15_meant * 1e-24 * dx;
    Y_N14_N13t(i) = rho_N14_At * sigma_N14_N13t * 1e-24 * dx;
    Y_N14_C11t(i) = rho_N14_At * sigma_N14_C11t * 1e-24 * dx;
    Y_C12_C11t(i) = rho_C12_At * sigma_C12_C11t * 1e-24 * dx;
    Y_C12_C10t(i) = rho_C12_At * sigma_C12_C10t * 1e-24 * dx;
end

%% Create plots

% Figure in water
figure
subplot(2,1,1)
plot(x,E)
xlabel('Depth (cm)');
ylabel('Energy (MeV) // Dose (a.u.)')
title('Water + Zn');
hold on
plot(x,100*Ddep)
legend('Energy','Dose')
set(gca,'FontSize',14)
axis([0 20 0 400]);
subplot(2,1,2)
title('Yields of different species (per incoming proton)');
hold on
plot(x,Y64,'b-'); hold on
plot(x,Y66,'r-')
plot(x,Y68,'g-')
plot(x,Y_O16_C11,'k'); hold on
plot(x,Y_O16_N13,'c')
plot(x,Y_O16_O15,'m')
legend('Zn64','Zn66','Zn68','C11','N13','O15','Location', 'Southeast');
xlabel('Depth (cm)');
ylabel('Yield');
plot(x,Y64s,'b:'); hold on
plot(x,Y66s,'r:')
plot(x,Y68s,'g:')
plot(x,Y_O16_C11s,'k:'); hold on
plot(x,Y_O16_N13s,'c:')
plot(x,Y_O16_O15s,'m:')
set(gca,'FontSize',14)
axis([0 20 0 1e-4]);

% Figure in tisssue
figure
subplot(2,1,1)
plot(x,Et)
xlabel('Depth (cm)');
ylabel('Energy (MeV) // Dose (a.u.)')
title('Tissue + Zn');
hold on
plot(x,100*Ddept)
legend('Energy','Dose')
set(gca,'FontSize',14)
axis([0 24 0 400]);
subplot(2,1,2)
title('Yields of different species (per incoming proton)');
hold on
plot(x,Y64t,'b'); hold on
plot(x,Y66t,'r')
plot(x,Y68t,'g')
Y_C11t = Y_O16_C11t + Y_C12_C11t + Y_N14_C11t;
Y_N13t = Y_O16_N13t + Y_N14_N13t;
Y_O15t = Y_O16_O15t;
Y_C10t = Y_C12_C10t;
plot(x,Y_C11t,'k'); hold on
plot(x,Y_N13t,'c')
plot(x,Y_O15t,'m')
plot(x,Y_C10t,'y');
legend('Zn64','Zn66','Zn68','C11','N13','O15','C10','Location', 'Southeast');
axis([0 24 0 1e-4]);
xlabel('Depth (cm)');
ylabel('Yield');
set(gca,'FontSize',14)

%% PET activity (t)
calcTimes = [0 3600 20000]; % s
act_C11_Zn = zeros(numel(calcTimes), numel(x));
act_N13_Zn = zeros(numel(calcTimes), numel(x));
act_O15_Zn = zeros(numel(calcTimes), numel(x));
act_Ga64_Zn = zeros(numel(calcTimes), numel(x));
act_Ga66_Zn = zeros(numel(calcTimes), numel(x));
act_Ga68_Zn = zeros(numel(calcTimes), numel(x));

act_C11_Znt = zeros(numel(calcTimes), numel(x));
act_C10_Znt = zeros(numel(calcTimes), numel(x));
act_N13_Znt = zeros(numel(calcTimes), numel(x));
act_O15_Znt = zeros(numel(calcTimes), numel(x));
act_Ga64_Znt = zeros(numel(calcTimes), numel(x));
act_Ga66_Znt = zeros(numel(calcTimes), numel(x));
act_Ga68_Znt = zeros(numel(calcTimes), numel(x));

for i=1:numel(calcTimes)
    % Water
    act_C11_Zn(i,:) = landa_C11 .* Y_O16_C11s .* exp(- landa_C11 * calcTimes(i));
    act_N13_Zn(i,:) = landa_N13 .* Y_O16_N13s .* exp(- landa_N13 * calcTimes(i));
    act_O15_Zn(i,:) = landa_O15 .* Y_O16_O15s .* exp(- landa_O15 * calcTimes(i));
    act_Ga64_Zn(i,:) = landa_Ga64 .* Y64s .* exp(- landa_Ga64 * calcTimes(i));
    act_Ga66_Zn(i,:) = landa_Ga66 .* Y66s .* exp(- landa_Ga66 * calcTimes(i));
    act_Ga68_Zn(i,:) = landa_Ga68 .* Y68s .* exp(- landa_Ga68 * calcTimes(i));
    
    % Tissue
    act_C11_Znt(i,:) = landa_C10 .* Y_C11t .* exp(- landa_C11 * calcTimes(i));
    act_C10_Znt(i,:) = landa_C11 .* Y_C10t .* exp(- landa_C11 * calcTimes(i));    
    act_N13_Znt(i,:) = landa_N13 .* Y_N13t .* exp(- landa_N13 * calcTimes(i));
    act_O15_Znt(i,:) = landa_O15 .* Y_O15t .* exp(- landa_O15 * calcTimes(i));
    act_Ga64_Znt(i,:) = landa_Ga64 .* Y64t .* exp(- landa_Ga64 * calcTimes(i));
    act_Ga66_Znt(i,:) = landa_Ga66 .* Y66t .* exp(- landa_Ga66 * calcTimes(i));
    act_Ga68_Znt(i,:) = landa_Ga68 .* Y68t .* exp(- landa_Ga68 * calcTimes(i));    
end
act_total = (1/(1-Zn_fraction))*(act_C11_Zn + act_N13_Zn + act_O15_Zn);
act_total_Zn = act_C11_Zn + act_N13_Zn + act_O15_Zn + act_Ga64_Zn + act_Ga66_Zn + act_Ga68_Zn;
act_totalt = (1/(1-Zn_fraction))*(act_C11_Znt + act_C10_Znt + act_N13_Znt + act_O15_Znt);
act_total_Znt = act_C11_Znt + act_C10_Znt + act_N13_Znt + act_O15_Znt + act_Ga64_Znt + act_Ga66_Znt + act_Ga68_Znt;

for i=1:numel(calcTimes)
    figure
    plot(x, act_total(i,:),'b')
    hold on
    plot(x, act_total_Zn(i,:),'r')
    axis([0 30 0 max(max(act_total_Zn(i,:)),max(act_total(i,:)))])
    title(sprintf('Activity at t=%i s post irradiation',calcTimes(i)));
    xlabel('Depth (cm)')
    ylabel('Beta+ emitters / s per incoming proton');
    legend('In water',sprintf('In water + %i%% natural Zn',round(Zn_fraction*100)), 'Location', 'Southwest');
    
    set(gca, 'FontSize', 16)
    
    figure
    plot(x, act_totalt(i,:),'b')
    hold on
    plot(x, act_total_Znt(i,:),'r')
    title(sprintf('Activity at t=%i s post irradiation',calcTimes(i)));
    xlabel('Depth (cm)')
    ylabel('Beta+ emitters / s per incoming proton');
    legend('In tissue',sprintf('In tissue + %i%% natural Zn',round(Zn_fraction*100)), 'Location', 'Southwest');
    set(gca, 'FontSize', 16)    
end
